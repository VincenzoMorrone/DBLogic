package com.DBCompany;

import junit.framework.TestCase;

public class DBConnectionTest extends TestCase {

}